import torch.nn as nn
import torch
def gumbel_softmax_sample(logits, temperature=1.0):
    randm=torch.rand_like(logits)*0.999
    randm=randm+1e-5
    gumbel_noise = -torch.log(-torch.log(randm))
    
    y = logits + gumbel_noise
    
    return F.softmax(y / temperature, dim=-1)

import torch
import torch.nn.functional as F

def gumbel_softmax(logits, temperature=1.0, hard=False, top_k=2):
    """
    对给定的 logits 应用 Gumbel Softmax，并保留最大的top_k个值。
    """
    device = logits.device
    y = gumbel_softmax_sample(logits, temperature)
    
    if hard:
        # 创建一个与logits形状相同的张量，初始化为0，同时指定与logits相同的数据类型和设备
        y_hard = torch.zeros_like(logits, dtype=logits.dtype, device=device)
        # 找到每个样本中最大的top_k个值的索引
        topk_values, topk_indices = torch.topk(y, top_k, dim=-1)
        # 将topk_values转换为与y_hard相同的数据类型和设备
        topk_values = topk_values.to(logits.dtype).to(device)
        # 使用这些索引在y_hard中设置值为1.0
        y_hard.scatter_(-1, topk_indices, 1)
        # 将非top_k的值置为0
        y_hard = torch.where(torch.isin(torch.arange(y.size(-1)).unsqueeze(0).to(device), topk_indices), y_hard, torch.tensor(0.0, dtype=logits.dtype, device=device))
        # 确保梯度仍然基于原始的y
        y = (y_hard - y).detach() + y
    return y

class MOE_Expert(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(MOE_Expert, self).__init__()
        self.layer1_text = nn.Linear(input_dim, hidden_dim).to(torch.device("cuda"))
        self.layer2_text = nn.Linear(hidden_dim, output_dim).to(torch.device("cuda"))
        self.layer1_image = nn.Linear(input_dim, hidden_dim).to(torch.device("cuda"))
        self.layer2_image = nn.Linear(hidden_dim, output_dim).to(torch.device("cuda"))

    def forward(self, x):
        text=x[:,0:40,:].to(torch.device("cuda"))
        image=x[:,40:,:].to(torch.device("cuda"))
        text = self.layer2_text(torch.relu(self.layer1_text(text)))
        image = self.layer2_image(torch.relu(self.layer1_image(image)))
        x=torch.cat((text,image),dim=1).to(torch.device("cuda"))
        return x
class MOE_crossattn_Expert(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim, num_heads):
        super(MOE_crossattn_Expert, self).__init__()
        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.num_heads = num_heads

        # Linear layers
        self.layer1_text = nn.Linear(input_dim, hidden_dim)
        self.layer2_text = nn.Linear(hidden_dim, output_dim)
        self.layer1_image = nn.Linear(input_dim, hidden_dim)
        self.layer2_image = nn.Linear(hidden_dim, output_dim)

        # MultiheadAttention for cross attention between text and image
        self.text_image_attention = nn.MultiheadAttention(embed_dim=hidden_dim, num_heads=num_heads)
        self.image_text_attention = nn.MultiheadAttention(embed_dim=hidden_dim, num_heads=num_heads)

    def forward(self, x):
        text = x[:, 0:40, :]
        image = x[:, 40:, :]

        text = torch.relu(self.layer1_text(text))
        image = torch.relu(self.layer1_image(image))
        text = text.transpose(0, 1)  
        image = image.transpose(0, 1)  # 

        text_attended, _ = self.text_image_attention(query=text, key=image, value=image)
        image_attended, _ = self.image_text_attention(query=image, key=text, value=text)
        text_attended = text_attended.transpose(0, 1)  
        image_attended = image_attended.transpose(0, 1) 
        text = text.transpose(0, 1)  
        image = image.transpose(0, 1)  # 
        text_attended=text_attended+text
        image_attended=image_attended+image
        text_out = self.layer2_text(text_attended)
        image_out = self.layer2_image(image_attended)

        x = torch.cat((text_out, image_out), dim=1)

        return x
# class MOE_channel_Expert(nn.Module):
#     def __init__(self, input_dim, hidden_dim, output_dim):
#         super(MOE_channel_Expert, self).__init__()
#         self.input_dim=input_dim
#         self.hidden_dim=hidden_dim
#         self.output_dim=output_dim
#         self.layer1_text = nn.Linear(input_dim, hidden_dim)
#         self.layer2_text = nn.Linear(hidden_dim, output_dim)
#         self.layer1_image = nn.Linear(input_dim, hidden_dim)
#         self.layer2_image = nn.Linear(hidden_dim, output_dim)
#         self.sigmoid=nn.Sigmoid()
#     def forward(self, x):

#         text=x[:,0:40,:].to(torch.device("cuda"))
#         image=x[:,40:,:].to(torch.device("cuda"))
#         # 10,40,768   10,901,768
#         image_avg=torch.mean(image,dim=1).unsqueeze(-2)
#         vl_query=torch.mean(image_avg*text,dim=1).unsqueeze(-2)
#         # vl_query = self.layer2_text(torch.relu(self.layer1_text(vl_query)))
#         vl_query=self.sigmoid(vl_query)
#         text_out=self.layer2_text(torch.relu(self.layer1_text(text)))
#         text_out=text_out*(vl_query+1)

#         text_avg=torch.mean(text,dim=1).unsqueeze(-2)
#         lv_query=torch.mean(text_avg*image,dim=1).unsqueeze(-2)
#         # lv_query =self.layer2_image(torch.relu(self.layer1_image(vl_query)))
#         lv_query=self.sigmoid(lv_query)
#         image_out=self.layer2_image(torch.relu(self.layer1_image(image)))
#         image_out=image_out*(lv_query+1)
#         x=torch.cat((text_out,image_out),dim=1).to(device="cuda")

#         return x
   
class MOE_spatial_Expert(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(MOE_spatial_Expert, self).__init__()
        self.input_dim=input_dim
        self.hidden_dim=hidden_dim
        self.output_dim=output_dim
        self.layer1_text = nn.Linear(input_dim, hidden_dim).to(torch.device("cuda"))
        self.layer2_text = nn.Linear(hidden_dim, output_dim).to(torch.device("cuda"))
        self.layer1_image = nn.Linear(input_dim, hidden_dim).to(torch.device("cuda"))
        self.layer2_image = nn.Linear(hidden_dim, output_dim).to(torch.device("cuda"))
        self.layernorm=nn.LayerNorm(768).to(torch.device("cuda"))
        self.sigmoid=nn.Sigmoid()
    def forward(self, x):
        # x=self.layernorm(x)
        text=x[:,0:40,:].to(torch.device("cuda"))
        image=x[:,40:,:].to(torch.device("cuda"))
    # 10,40,768   10,901,768
        image_avg=torch.mean(image,dim=1).unsqueeze(-2)
        vl_query=torch.mean(image_avg*text,dim=-1).unsqueeze(-1).transpose(2,1)
        vl_query=self.sigmoid(vl_query)
        vl_query=torch.bmm(vl_query,text)
        vl_query=self.sigmoid(vl_query)
        text_out = self.layer2_text(torch.relu(self.layer1_text(text)))
        text_out=text_out*(vl_query+1)

        text_avg=torch.mean(text,dim=1).unsqueeze(-2)
        lv_query=torch.mean(text_avg*image,dim=-1).unsqueeze(-1).transpose(2,1)
        lv_query=self.sigmoid(lv_query)
        lv_query=torch.bmm(lv_query,image)
        lv_query=self.sigmoid(lv_query)
        image_out =self.layer2_image(torch.relu(self.layer1_image(image)))
        image_out=image_out*(lv_query+1)
        
        x=torch.cat((text_out,image_out),dim=1).to(device="cuda")

        return x
class MOE_Gating_all(nn.Module):
    def __init__(self, input_dim,
                num_experts, dropout_rate=0.1,top_k=1):
        super(MOE_Gating_all, self).__init__()
        # Layers
        self.layer1 = nn.Linear(input_dim, 64)
        self.dropout1 = nn.Dropout(dropout_rate)
        self.layer2=nn.Linear(64,num_experts)
        # self.layer2 = nn.Linear(128, 256)
        # self.leaky_relu1 = nn.LeakyReLU()
        # self.dropout2 = nn.Dropout(dropout_rate)
        # self.layer3 = nn.Linear(256, 128)
        # self.leaky_relu2 = nn.LeakyReLU()
        # self.dropout3 = nn.Dropout(dropout_rate)
        # self.layer4 = nn.Linear(128, num_experts)
        self.top_k=top_k
    def forward(self, x):
        x = torch.relu(self.layer1(x))#128
        x = self.dropout1(x)
        x = self.layer2(x)#256
        # x = self.leaky_relu1(x)
        # x = self.dropout2(x)
        # x = self.layer3(x)
        # x = self.leaky_relu2(x)
        # x = self.dropout3(x)
        # x = self.layer4(x)
            
        out=gumbel_softmax(x,1.0,True,self.top_k)
        # out=F.softmax(x,-1)
        return out

class MOE_Gating(nn.Module):
    def __init__(self, input_dim,
                num_experts, dropout_rate=0.1,top_k=1):
        super(MOE_Gating, self).__init__()
        # Layers
        self.layer1 = nn.Linear(input_dim, 64)
        self.dropout1 = nn.Dropout(dropout_rate)
        self.layer2=nn.Linear(64,num_experts)
        # self.layer2 = nn.Linear(128, 256)
        # self.leaky_relu1 = nn.LeakyReLU()
        # self.dropout2 = nn.Dropout(dropout_rate)
        # self.layer3 = nn.Linear(256, 128)
        # self.leaky_relu2 = nn.LeakyReLU()
        # self.dropout3 = nn.Dropout(dropout_rate)
        # self.layer4 = nn.Linear(128, num_experts)
        self.top_k=top_k
    def forward(self, x):
        x = torch.relu(self.layer1(x))#128
        x = self.dropout1(x)
        x = self.layer2(x)#256
        # x = self.leaky_relu1(x)
        # x = self.dropout2(x)
        # x = self.layer3(x)
        # x = self.leaky_relu2(x)
        # x = self.dropout3(x)
        # x = self.layer4(x)
            
        # out=gumbel_softmax(x,1.0,True,self.top_k)
        out=F.softmax(x,-1)
        return out


class MOE_adapter(nn.Module):
    def __init__(self, channel_attn=True, spatial_attn=True, cross_attn=True):
        super(MOE_adapter, self).__init__()
        self.uni_experts = nn.ModuleList([MOE_Expert(768, 64, 768) for _ in range(2)])
        self.cross_experts = nn.ModuleList([MOE_crossattn_Expert(768, 64, 768, 2) for _ in range(2)])
        self.chan_experts = nn.ModuleList([MOE_channel_Expert(768, 64, 768) for _ in range(2)])
        self.spat_experts = nn.ModuleList([MOE_spatial_Expert(768, 64, 768) for _ in range(2)])
        self.is_channel = channel_attn
        self.is_spatial = spatial_attn
        self.is_cross = cross_attn
        self.layernorm = nn.LayerNorm(768)
        self.gating1 = MOE_Gating(768, 2, top_k=1)
        self.gating2 = MOE_Gating(768, 2, top_k=1)
        self.gating3 = MOE_Gating(768, 2, top_k=1)
        self.gating4 = MOE_Gating(768, 2, top_k=1)
        self.globle_gate=MOE_Gating_all(768,4,top_k=1)
        # self.gate=nn.Sequential(nn.Linear(768,64),
        #                         nn.ReLU(),
        #                         nn.Linear(64,3),
        #                         nn.Softmax(dim=-1))

    def forward(self, x):
        weights1 = self.gating1(x)
        weights2 = self.gating2(x)
        weights3 = self.gating3(x)
        weights4 = self.gating4(x)
        all_weight=self.globle_gate(torch.mean(x,dim=1))
        print(all_weight)

        outputs_list = []
        for expert in self.uni_experts:
            output_expert = expert(x)
            outputs_list.append(output_expert)
        uni_outputs_stacked = torch.stack(outputs_list, dim=3)
        
        outputs_list = []
        for expert in self.cross_experts:
            output_expert = expert(x)
            outputs_list.append(output_expert)
        
        cross_outputs_stacked = torch.stack(outputs_list, dim=3)
        
        outputs_list = []
        for expert in self.chan_experts:
            output_expert = expert(x)
            outputs_list.append(output_expert)
        
        chan_outputs_stacked = torch.stack(outputs_list, dim=3)

        outputs_list = []
        for expert in self.spat_experts:
            output_expert = expert(x)
            outputs_list.append(output_expert)
        
        spat_outputs_stacked = torch.stack(outputs_list, dim=3)
    
        weights1 = weights1.unsqueeze(2).expand_as(uni_outputs_stacked)
        weights2 = weights2.unsqueeze(2).expand_as(cross_outputs_stacked)
        weights3 = weights3.unsqueeze(2).expand_as(chan_outputs_stacked)
        weights4 = weights4.unsqueeze(2).expand_as(spat_outputs_stacked)
        

        uni_product = uni_outputs_stacked * weights1
        cross_product = cross_outputs_stacked * weights2
        chan_product = chan_outputs_stacked * weights3
        spat_product = spat_outputs_stacked *weights4

        uni_ans = torch.sum(uni_product, dim=3)
        cross_ans = torch.sum(cross_product, dim=3)
        chan_ans = torch.sum(chan_product, dim=3)
        spat_ans=torch.sum(spat_product, dim=3)
        print("max uni",torch.max(uni_ans),"cross",torch.max(cross_ans),"chan",torch.max(cross_ans),"spat",torch.max(spat_ans))

        mixture_ans=torch.stack([uni_ans,cross_ans,chan_ans,spat_ans], dim=1)
        print("all",all_weight.size(),"mix",mixture_ans.size())
        out_list=[]
        for i in range(all_weight.size(0)):
            print(all_weight[i,:])
            if(all_weight[i,0]==1):
                print("uni")
                out_list.append(uni_ans[i,...].unsqueeze(0))
            elif(all_weight[i,1]==1):
                print("cross")
                out_list.append(cross_ans[i,...].unsqueeze(0))
            elif(all_weight[i,2]==1):
                print("chan")
                out_list.append(chan_ans[i,...].unsqueeze(0))
            else:
                # out_list.append(spat_ans[i,...].unsqueeze(0))
                print("...",spat_ans[i,...].size())
                print("spat")
        ans=torch.cat(out_list)
        print("ouli",ans.size())
        # ans=all_weight*mixture_ans
        # print("ans",ans.size())
        
        return ans
    
class MOE_channel_Expert(nn.Module):
    def __init__(self, input_dim, hidden_dim, output_dim):
        super(MOE_channel_Expert, self).__init__()
        self.input_dim=input_dim
        self.hidden_dim=hidden_dim
        self.output_dim=output_dim
        self.layer1_text = nn.Linear(input_dim, hidden_dim)
        self.layer2_text = nn.Linear(hidden_dim, output_dim)
        self.layer1_image = nn.Linear(input_dim, hidden_dim)
        self.layer2_image = nn.Linear(hidden_dim, output_dim)
        self.sigmoid=nn.Sigmoid()
    def forward(self, x):

        text=x[:,0:40,:].to(torch.device("cuda"))
        image=x[:,40:,:].to(torch.device("cuda"))
        # 10,40,768   10,901,768
        image_avg=torch.mean(image,dim=1).unsqueeze(-2)
        vl_query=(image_avg*text)
        print("vlq",vl_query.size())
        # vl_query = self.layer2_text(torch.relu(self.layer1_text(vl_query)))
        vl_query=self.sigmoid(vl_query)
        text_out=self.layer2_text(torch.relu(self.layer1_text(text)))
        print("vl",vl_query.size())
        text_out=text_out*(vl_query+1)

        text_avg=torch.mean(text,dim=1).unsqueeze(-2)
        lv_query=torch.mean(text_avg*image,dim=1).unsqueeze(-2)
        # lv_query =self.layer2_image(torch.relu(self.layer1_image(vl_query)))
        lv_query=self.sigmoid(lv_query)
        image_out=self.layer2_image(torch.relu(self.layer1_image(image)))
        image_out=image_out*(lv_query+1)
        x=torch.cat((text_out,image_out),dim=1).to(device="cuda")

        return x
    

x=torch.rand(10,940,768).to("cuda")*452841
adp=MOE_channel_Expert(768,16,768).to("cuda")
out=adp(x)
print("in",torch.max(x))
print("out",torch.max(out))
