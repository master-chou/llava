import sys
sys.path.append('/home/maiyubo/llm/LLaVA')
from sam2.sam2_image_predictor import SAM2ImagePredictor
import torch
import torch.nn as nn
from sam2.build_sam import build_sam2


class SamVisionTower(nn.Module):
    def __init__(self, delay_load=False):
        super().__init__()
        self.is_loaded=False

        self.checkpoint = "/home/maiyubo/llm/LLaVA/sam2_hiera_tiny.pt"
        self.model_cfg = "sam2_hiera_t.yaml"
        if not delay_load:
            self.load_model()
        else:
            pass
        self.select_feature = 'patch'
    def load_model(self, device_map=None):
        if self.is_loaded:
            print('{} is already loaded, `load_model` called again, skipping.'.format(self.vision_tower_name))
            return
        self.predictor = SAM2ImagePredictor(build_sam2(self.model_cfg, self.checkpoint))
        self.is_loaded = True

    def feature_select(self, image_forward_output):
        image_features = image_forward_output
        if self.select_feature == 'patch':
            image_features = image_features[:, 1:]
        elif self.select_feature == 'cls_patch':
            image_features = image_features
        return image_features

    @torch.no_grad()
    def forward(self, images):
        with torch.inference_mode(), torch.autocast("cuda", dtype=torch.bfloat16):
            if type(images) is list:
                image_features = []
                for image in images:
                    self.predictor.set_image(image.to(device=self.device, dtype=self.dtype))
                    image_forward_out = self.predictor._features['image_embed']
                    image_feature = self.feature_select(image_forward_out).to(image.dtype)
                    image_features.append(image_feature)
            else:
                self.predictor.set_image(images.to(device=self.device, dtype=self.dtype))
                image_forward_outs = self.predictor._features['image_embed']
                image_features = self.feature_select(image_forward_outs).to(images.dtype)
            return image_features

    @property
    def dummy_features(self):
        return None

    @property
    def num_patches_per_side(self):
        return 1024 // 16

    @property
    def num_patches(self):
        return (1024 // 16) ** 2

    @property
    def dtype(self):
        return self.vision_tower.dtype

    @property
    def device(self):
        return self.vision_tower.device

