# import os
# from .clip_encoder import CLIPVisionTower, CLIPVisionTowerS2


# def build_vision_tower(vision_tower_cfg, **kwargs):
#     vision_tower = getattr(vision_tower_cfg, 'mm_vision_tower', getattr(vision_tower_cfg, 'vision_tower', None))
#     is_absolute_path_exists = os.path.exists(vision_tower)
#     use_s2 = getattr(vision_tower_cfg, 's2', False)
#     if is_absolute_path_exists or vision_tower.startswith("openai") or vision_tower.startswith("laion") or "ShareGPT4V" in vision_tower:
#         if use_s2:
#             return CLIPVisionTowerS2(vision_tower, args=vision_tower_cfg, **kwargs)
#         else:
#             return CLIPVisionTower(vision_tower, args=vision_tower_cfg, **kwargs)

#     raise ValueError(f'Unknown vision tower: {vision_tower}')

import os
from .clip_encoder import CLIPVisionTower, CLIPVisionTowerS2
from .swin_encoder import SwinVisionTower
from .mae_encoder import  MaeVisionTower
from .dino_encoder import DinoVisionTower
from .sam_encoder import SamVisionTower

def build_vision_tower(vision_tower_cfg, **kwargs):
    # import pdb;pdb.set_trace()
    vision_tower = getattr(vision_tower_cfg, 'mm_vision_tower', getattr(vision_tower_cfg, 'vision_tower', None))
    is_absolute_path_exists = os.path.exists(vision_tower)
    use_s2 = getattr(vision_tower_cfg, 's2', False)
    if is_absolute_path_exists or vision_tower.startswith("openai") or vision_tower.startswith("laion") or "ShareGPT4V" in vision_tower:
        if use_s2:
            return CLIPVisionTowerS2(vision_tower, args=vision_tower_cfg, **kwargs)
        else:
            return CLIPVisionTower(vision_tower, args=vision_tower_cfg, **kwargs)
            # vision_tower is path, args
            # return SwinVisionTower()

    raise ValueError(f'Unknown vision tower: {vision_tower}')


def build_swin_tower(vision_tower_cfg, **kwargs):
    return SwinVisionTower("swin_tower", args=vision_tower_cfg, **kwargs)

def build_mae_tower(**kwargs):
    return MaeVisionTower(**kwargs)

def build_sam_tower(**kwargs):
    return SamVisionTower(**kwargs)

def build_dino_tower(**kwargs):
    return DinoVisionTower(**kwargs)
 
