import torch
import torch.nn as nn

class DinoVisionTower(nn.Module):
    def __init__(self,delay_load=False):
        super().__init__()
        self.is_loaded=False
        self.dino_model = torch.hub.load('/home/maiyubo/llm/LLaVA/dinov2', 'dinov2_vits14',
                               pretrained=False, trust_repo=True, source='local')
        self.select_feature = 'patch'
        if not delay_load:
            self.load_model()
        else:
            pass
    
    def load_model(self, device_map=None):
        if self.is_loaded:
            print('{} is already loaded, `load_model` called again, skipping.'.format(self.vision_tower_name))
            return
        self.dino_model.load_state_dict(torch.load('/home/maiyubo/llm/LLaVA/dinov2_vits14_reg4_pretrain.pth'),
                              strict=False)
        self.is_loaded = True

    def feature_select(self, image_forward_output):
        image_features = image_forward_output
        if self.select_feature == 'patch':
            image_features = image_features[:, 1:]
        elif self.select_feature == 'cls_patch':
            image_features = image_features
        return image_features

    @torch.no_grad()
    def forward(self, images):
        self.mae_model.requires_grad_(False)
        if type(images) is list:
            image_features = []
            for image in images:
                image_forward_out = self.dino_model(image.to(device=self.device, dtype=self.dtype).unsqueeze(0))
                image_feature = self.feature_select(image_forward_out).to(image.dtype)
                image_features.append(image_feature)
        else:
            image_forward_outs = self.dino_model(images.to(device=self.device, dtype=self.dtype))
            image_features = self.feature_select(image_forward_outs).to(images.dtype)
        return image_features

    @property
    def dummy_features(self):
        return None

    @property
    def num_patches_per_side(self):
        return 224 // 16

    @property
    def num_patches(self):
        return (224 // 16) ** 2

    @property
    def dtype(self):
        return self.dino_model.dtype

    @property
    def device(self):
        return self.dino_model.device

